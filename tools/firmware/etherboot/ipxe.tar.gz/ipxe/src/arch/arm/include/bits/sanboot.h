#ifndef _BITS_SANBOOT_H
#define _BITS_SANBOOT_H

/** @file
 *
 * ARM-specific sanboot API implementations
 *
 */

FILE_LICENCE ( GPL2_OR_LATER_OR_UBDL );

#endif /* _BITS_SANBOOT_H */
