#ifndef _BITS_TIME_H
#define _BITS_TIME_H

/** @file
 *
 * ARM-specific time API implementations
 *
 */

FILE_LICENCE ( GPL2_OR_LATER_OR_UBDL );

#endif /* _BITS_TIME_H */
